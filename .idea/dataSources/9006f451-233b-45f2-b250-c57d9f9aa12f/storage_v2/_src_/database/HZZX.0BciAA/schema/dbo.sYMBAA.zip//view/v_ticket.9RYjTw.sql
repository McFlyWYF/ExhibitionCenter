create view v_ticket (no,t_name,sex,work,m_name,p_name,price) as select Ano,Aname,Asex,Awork,Meeting.Mname,Place.Pname,Meeting.Mprice from Ticket,Meeting,Place where Ticket.Mno = Meeting.Mno and Meeting.Pno = Place.Pno;
go

