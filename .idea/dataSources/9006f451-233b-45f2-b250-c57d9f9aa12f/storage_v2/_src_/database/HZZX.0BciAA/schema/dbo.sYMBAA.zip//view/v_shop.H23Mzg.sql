create view v_shop (no,s_name,t_name,kind,time,price) as select Shop.Sno,Shop.Sname,Thing.Tname,Thing.Tkind,Shop.Stime,Thing.Tprice from Shop,Thing where Shop.Tno = Thing.Tno;
go

