create view v_reserve (no,p_name,name,time,num) as select Reserve.RNO,Place.Pname,Reserve.Bname,Reserve.Rtime,Reserve.Rnum from Reserve,Place where Place.Pno = Reserve.Pno;
go

